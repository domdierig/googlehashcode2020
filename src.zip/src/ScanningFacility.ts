export class ScanningFacility {
    constructor(public readonly daysForScanning: number) {
        
    }
}