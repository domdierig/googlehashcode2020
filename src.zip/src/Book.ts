export class Book {

    constructor(
        public readonly id: number,
        public readonly score: number
    ) {
    }

}